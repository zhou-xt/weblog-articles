# 《MySQL 是怎样运行的：从根儿上理解 MySQL》
来自于掘金小册：https://juejin.im/book/5bffcbc9f265da614b11b731

## 打包下载
PDF下载地址：https://share.weiyun.com/tVcnGDKx